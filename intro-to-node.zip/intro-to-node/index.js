// superheroes

const superheroes = require('superheroes');

var myheroName = superheroes.random();

console.log(myheroName);

///////supervillains////////////////
const supervillains = require('supervillains');

 var myvillainName = supervillains.random();

 console.log(myvillainName);
